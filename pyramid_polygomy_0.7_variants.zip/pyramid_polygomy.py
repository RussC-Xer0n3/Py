#! /usr/bin/env python3

# version 0.1

import math

float h = pow(24.0, 12)
float l = pow(32, 6)

float p = (H, l)
