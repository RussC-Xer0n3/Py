#! /usr/bin/env python3

# version 0.2

import math

float h = pow(24.0, 12)
float l = pow(32, 6)

float p = sum(H, l)
